# MQDeck Agent

The MQDeck Agent is a read-only remote diagnostic executor. It opens an
authenticated outbound WebSocket to `mqdeck-api`, waits for a correlated
request, validates the supplied inventory target, runs the adapter checks, and
returns the result over the same connection.

It does not schedule collections, write telemetry, require Elasticsearch, or
listen on an inbound port in on-demand mode.

## Configure

```bash
cp mqdeck.on-demand.example.yaml mqdeck.yaml
export MQDECK_API_URL=https://mqdeck.example.com
export MQDECK_AGENT_TOKEN='replace-with-the-api-token'
go run ./cmd/mqdeck-agent -config mqdeck.yaml
```

Give every installation a globally unique `agent.id`. `agent.name` is the
operator-facing name displayed by the platform. Multiple agents can reach
different network zones; an inventory host can name its preferred Agent.

## Connection model

- Agent initiates the connection and reconnects automatically.
- `wss://` is required outside local development.
- A heartbeat keeps presence current; disconnecting removes the Agent from the
  selectable list.
- `max_concurrency` bounds simultaneous diagnostic requests.
- Broker credentials arrive only as part of the bounded request and are not
  stored by the Agent.

## Safety

The adapters keep their existing read-only restrictions. RabbitMQ HTTP checks
use `GET`; IBM MQ client/local commands must be a single `DISPLAY` MQSC command.
The Agent rejects invalid transports, endpoints, commands, and targets before
execution. Test Flight and arbitrary remote command execution are not exposed.

```bash
go test ./...
```
