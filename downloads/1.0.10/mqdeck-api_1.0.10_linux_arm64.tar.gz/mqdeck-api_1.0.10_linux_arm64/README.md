# MQDeck API

`mqdeck-api` is the control plane for the simplified, on-demand MQDeck.
It loads the broker inventory from YAML, accepts outbound WebSocket connections
from Agents, dispatches correlated read-only diagnostics, and normalizes the
ephemeral result for the Web interface. It does not require Elasticsearch.

## Configuration

| Variable | Default |
| --- | --- |
| `MQDECK_API_ADDRESS` | `:8080` |
| `MQDECK_INVENTORY_PATH` | `./inventory.yaml` |
| `MQDECK_AGENT_TOKEN` | required |
| `MQDECK_DIAGNOSTIC_TIMEOUT` | `45s` |
| `MQDECK_CORS_ORIGINS` | `http://localhost:3000` |

Copy `inventory.example.yaml` to `inventory.yaml`, replace every example value
with its final literal value, restrict the file permissions, and start the API:

```bash
cp inventory.example.yaml inventory.yaml
chmod 600 inventory.yaml
export MQDECK_AGENT_TOKEN='replace-with-a-long-random-secret'
go run ./cmd/mqdeck-api
```

The inventory is intentionally static and self-contained. Environment-variable
placeholders such as `${BROKER_PASSWORD}` are rejected instead of expanded.
Keep one inventory entry per queue manager or RabbitMQ node. The YAML contains
only connection and Agent-routing data; MQDeck derives transport, safe checks,
timeouts, commands, output limits, and the endpoint machine. Multiple queue
managers may use the same endpoint host. Cluster and full/partial repository
roles are discovered from the current IBM MQ state instead of duplicated in
static metadata.

Minimal IBM MQ entry:

```yaml
- id: payments-qm
  adapter: ibmmq
  endpoint: mq01.example.net(1414)
  queue_manager: QM01
  channel: MQDECK.READONLY
  credentials:
    username: mqdeck_readonly
    password: replace-with-the-read-only-password
```

## HTTP surface

- `GET /healthz`
- `GET /api/v1/agents`
- `GET /api/v1/agents/connect` — authenticated WebSocket upgrade for Agents
- `GET /api/v1/hosts`
- `GET /api/v1/hosts/{id}`
- `GET /api/v1/hosts/{id}/report?agent={optional-agent-id}`

The report response contains both the normalized `data` and the individual
`evidence` checks. Neither is stored after the response completes.

```bash
go test ./...
```
