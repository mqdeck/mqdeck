# MQDeck Web

MQDeck Web is the read-only operational view for the MQDeck platform.

- Overview reads only the local inventory through the API and never contacts a broker.
- Agents shows the currently connected data collectors.
- Opening broker details requests a fresh, read-only snapshot through the preferred,
  automatic, or manually selected Agent.
- Queue manager details immediately show the current manager, channel, queue, and
  application-flow state. Snapshots are ephemeral and are not retained.
- Test Flight is not part of the simplified product.

## Run

```bash
cp .env.example .env.local
npm install
npm run dev
```

Set `MQDECK_API_URL` to the API base URL. Static Web authentication continues
to use `MQDECK_AUTH_USERNAME`, `MQDECK_AUTH_PASSWORD`, and
`MQDECK_AUTH_SESSION_SECRET`.

```bash
npm run typecheck
npm test
npm run build
```
